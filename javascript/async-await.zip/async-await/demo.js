async function getGithubData(username) {
  try {
    const userResponse = await fetch(
      `https://api.github.com/users/${username}`
    );
    if (!userResponse.ok) throw new Error("User not found!");

    const user = await userResponse.json();
    const reposResponse = await fetch(user.repos_url);
    const repos = await reposResponse.json();

    console.log(`${user.name} has ${repos.length} repos`);
  } catch (error) {
    console.log("Something went wrong: ", error.message);
  }
}

getGithubData("sbagaria2710");
