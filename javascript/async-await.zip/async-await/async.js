const value1 = "Scaler Academy";
const value2 = new Promise((resolve, reject) => {
  resolve("Promise Resolved!");
});

async function fetchData() {
  return value1;
}

const dataPromise = fetchData();
dataPromise.then((data) => {
  console.log(data);
});