// const p = new Promise((resolve, reject) => {
//   resolve("Promise Resolved");
// });

// async function handlePromise() {
//   const response = await p;
//   console.log(response);
// };

// function fetchData() {
//   p.then((response) => console.log(response));
// }

// fetchData();
// handlePromise();

// ------------------------------------------------------------
const p = new Promise((resolve, reject) => {
  setTimeout(function() {
    resolve("4");
  }, 5000);
});

async function handlePromise() {
  console.log("1");

  const response = await p; // event loop microtask queue

  console.log(response);
  console.log("2");
}

handlePromise();
console.log("3");