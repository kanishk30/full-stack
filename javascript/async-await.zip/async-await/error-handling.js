async function fetchData() {
  try {
    const res = await fetch("https://api.githubzzz.com/users/random_user");
    const data = await res.json();
    console.log(data);
  } catch (err) {
    console.log("Fetch Failed: ", err);
  }
}

fetchData();

// Handling multiple awaits in parallel
// SLOW WAY
// const user  = await fetchUser();
// const posts = await fetchPosts();

// FAST WAY
// const [user, posts] = Promise.all([fetchUser(), fetchPosts()]);
