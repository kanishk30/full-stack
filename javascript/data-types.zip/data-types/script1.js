let count = 0;

function increment() {
  count++;
};