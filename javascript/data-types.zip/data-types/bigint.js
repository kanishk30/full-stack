const largeNumber = 12345678901234567890890n;
const fromString = BigInt("9876543219876543213210");

// Big Int Operation
const product = largeNumber * fromString;
console.log("Product:", product);
