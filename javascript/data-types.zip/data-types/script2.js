let count = 10;

increment();

console.log(count); // ??