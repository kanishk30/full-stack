export function greet(name) {
  return `Hello, ${name}`;
};

export const PI = 3.14159;

export default function multiply(a, b) {
  return a * b;
};