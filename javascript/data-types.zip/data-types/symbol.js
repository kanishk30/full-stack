const string1 = "hello";
const string2 = "hello";

console.log(string1 === string2); // true

const array1 = [1, 2, 3];
const array2 = [1, 2, 3];

console.log(array1 === array2); // false

// ------------
// Creating Symbols
const symbol1 = Symbol("Testing");
const symbol2 = Symbol("Testing");

// Using Symbols as Object Properties
const person = {
  name: "Learner",
  age: 30,
  [symbol1]: "A person",
};

console.log(person[symbol1]); // "A person"
console.log(person[symbol2]); // undefined

// Checking Symbol Description
console.log(symbol1.toString()); // Symbol("Testing")
console.log(symbol1.description); // Testing1
