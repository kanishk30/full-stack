import scaler, { greet, PI } from "./util.mjs";

console.log(scaler(2, 3));