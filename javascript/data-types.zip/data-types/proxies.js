// OBject
let obj = {
  eng: "English",
  math: "Mathematics"
};

// Custom Handler
const handler = {
  get(target, prop) {
    if (prop in target) {
      return target[prop];
    } else {
      throw new Error("Property does not exist.");
    }
  },
  set(target, prop, value) {
    if (prop in target) {
      target[prop] = value;
      return true;
    } else {
      throw new Error("Cannot add a new property");
    }
  }
};

// Create Proxy
let proxy = new Proxy(obj, handler);

proxy.history = "History";